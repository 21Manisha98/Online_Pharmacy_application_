package com.example.onlinepharmacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinePharmacyApplicationTests {

	@Test
	void contextLoads() {
	}

}
