package com.example.project.Controllers;

import com.example.project.DTO.*;
import com.example.project.Models.*;
import com.example.project.Services.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("api/user")
public class UserController {

    @Autowired
    UserService userService;

    Date currentDate = new Date();

    // Profile CRUD

    @PostMapping("/AddProfile")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity AddProfile(@RequestBody ProfileDetail request) {
        try {


            String response = userService.AddProfile(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/UpdateProfile")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity UpdateProfile(@RequestBody ProfileDetail request) {

        try {
            String response = userService.UpdateProfile(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/GetProfile")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetProfile(@RequestParam Long UserId) {

        try {
            Optional<ProfileDetail> response = userService.GetProfile(UserId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    // Order CRUD

    @PostMapping("/AddOrder")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity AddOrder(@RequestBody OrderDetail request) {
        try {


            String response = userService.AddOrder(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/UpdateOrder")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity UpdateOrder( @RequestBody OrderDetail request) {

        try {
            String response = userService.UpdateOrder(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/GetOrderByUserID")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetOrderByUserID(@RequestParam Long UserId) {

        try {
            List<OrderDetail> response = userService.GetOrderByUserID(UserId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }


    @DeleteMapping("/DeleteOrderByID")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity DeleteOrderByID(@RequestParam Long Id) {

        try {
            String response = userService.DeleteOrderByID(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/user/deleteUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    // Review CRUD

    @PostMapping("/AddUserReview")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity AddUserReview(@RequestBody ReviewDetail request) {
        try {


            String response = userService.AddUserReview(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/UpdateUserReview")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity UpdateUserReview(@RequestBody ReviewDetail request) {

        try {
            String response = userService.UpdateUserReview(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/GetUserReviewListByUserID")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetUserReviewList(@RequestParam Long UserID) {

        try {
            List<GetReviewDetailListDAO> response = userService.GetUserReviewList(UserID);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/DeleteUserReview")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity DeleteUserReview(@RequestParam Long Id) {

        try {
            String response = userService.DeleteUserReview(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/user/deleteUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    // Query CRUD

    @PostMapping("/AddQuery")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity AddQuery(@RequestBody QueryDetail request) {
        try {


            String response = userService.AddQuery(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/UpdateQuery")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity UpdateQuery(@RequestBody QueryDetail request) {

        try {
            String response = userService.UpdateQuery(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/GetQueryList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetQueryList(@RequestParam Long UserID) {

        try {
            List<GetQueryDetailListDTO> response = userService.GetQueryList(UserID);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/DeleteQuery")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity DeleteQuery(@RequestParam Long Id) {

        try {
            String response = userService.DeleteQuery(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/user/deleteUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    //WishList
    @GetMapping("/GetWishList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetWishList(@RequestParam Long UserID) {

        try {
            List<OrderDetail> response = userService.GetWishList(UserID);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

}
