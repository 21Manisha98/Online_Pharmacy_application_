package com.example.project.Repositories;

import com.example.project.Models.QueryDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QueryDetailDAO extends JpaRepository<QueryDetail, Long> {
}
