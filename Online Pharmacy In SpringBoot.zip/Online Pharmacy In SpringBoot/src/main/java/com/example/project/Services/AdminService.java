package com.example.project.Services;

import com.example.project.DTO.GetReviewDetailListDAO;
import com.example.project.DTO.UserDetailRequestDTO;
import com.example.project.Enums.UserRole;
import com.example.project.Models.*;
import com.example.project.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    MedicineDetailDAO medicineDetailDAO;

    @Autowired
    OrderDetailDAO orderDetailDAO;

    @Autowired
    UserDAO userDAO;

    @Autowired
    ReviewDetailDAO reviewDetailDAO;

    @Autowired
    ProfileDetailDAO profileDetailDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    QueryDetailDAO queryDetailDAO;

    //Medicine CRUD
    public String AddMedicineDetail(MedicineDetail request) {

        try {
            medicineDetailDAO.save(request);
            return "Added Medicine Detail Successfully!";

        }catch (Exception ex)
        {
            return ex.getMessage();
        }

    }

    public String UpdateMedicineDetail(MedicineDetail request){

        try{

            Optional<MedicineDetail> response = medicineDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==request.getId())
                    .findFirst();

            if(!response.isPresent()) {
                return "Invalid Medicine Id";
            }

            /*
            private Long userID;
            private String name;
            private String description;
            private String category; //Tablet, cyrups
            private Long price;
            private String diseases;
            private Long stock;
            */
            response.get().setUserID(request.getUserID());
            response.get().setName(request.getName());
            response.get().setDescription(request.getDescription());
            response.get().setCategory(request.getCategory());
            response.get().setPrice(request.getPrice());
            response.get().setDiseases(request.getDiseases());
            response.get().setStock(request.getStock());
            medicineDetailDAO.save(response.get());

            return "Update Medicine Detail successfully";

        }catch (Exception ex){
            return ex.getMessage();
        }

    }

    public List<MedicineDetail> GetMedicineDetailList(){

        try{
            return medicineDetailDAO
                    .findAll()
                    .stream()
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String DeleteMedicineDetailL(Long Id){

        try{

            Optional<MedicineDetail> response = medicineDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Medicine Id";
            }

            medicineDetailDAO.delete(response.get());

            return "Delete Medicine Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    // UserDetail CRUD

    public String AddUserDetail(UserDetailRequestDTO request) {

        try {

            Optional<User> getUser = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getEmail().equalsIgnoreCase(request.getUsername()))
                    .findFirst();

            if(getUser.isPresent()){
                return "UserName Already Exist";
            }

            User user = new User();
            user.setRole(UserRole.USER);
            user.setEmail(request.getUsername());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            userDAO.save(user);

            getUser = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getEmail().equalsIgnoreCase(request.getUsername()))
                    .findFirst();

            ProfileDetail profileDetail = new ProfileDetail();
            profileDetail.setFullName(request.getFullName());
            profileDetail.setAddress(request.getAddress());
            profileDetail.setContact(request.getContact());
            profileDetail.setEmail(request.getEmail());
            profileDetail.setUserID(getUser.get().getUserId());
            profileDetail.setCreatedDate(new Date());
            profileDetailDAO.save(profileDetail);

            return "Added Profile Detail Successfully!";

        }catch (Exception ex)
        {
            return ex.getMessage();
        }

    }

    public String UpdateUserDetail(UserDetailRequestDTO request){

        try{

            Optional<ProfileDetail> response = profileDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserID()==request.getUserId())
                    .findFirst();

            if(!response.isPresent()) {
                ProfileDetail profileDetail = new ProfileDetail();
                profileDetail.setFullName(request.getFullName());
                profileDetail.setAddress(request.getAddress());
                profileDetail.setContact(request.getContact());
                profileDetail.setEmail(request.getEmail());
                profileDetail.setUserID(request.getUserId());
                profileDetail.setCreatedDate(new Date());
                profileDetailDAO.save(profileDetail);
                return "Create New Profile";
            }

            /*
            private String fullName;
            private String email;
            private String address;
            private String contact;
            */

            response.get().setFullName(request.getFullName());
            response.get().setEmail(request.getEmail());
            response.get().setAddress(request.getAddress());
            response.get().setContact(request.getContact());
            profileDetailDAO.save(response.get());

            return "Update Profile Detail successfully";

        }catch (Exception ex){
            return ex.getMessage();
        }

    }

    public List<UserDetailRequestDTO> GetUserDetailList(){

        try{
            List<User> userDataList = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getRole()==UserRole.USER)
                    .toList();

//            private Long userId;
//            private String username;
//            private String  password;
//            private UserRole role;

            //Profile Table
            //private Long userID;
//            private String fullName;
//            private String email;
//            private String address;
//            private String contact;

            List<UserDetailRequestDTO> getDataList = new ArrayList<>();
            userDataList.forEach(x->{
                UserDetailRequestDTO getData = new UserDetailRequestDTO();
                getData.setUserId(x.getUserId());
                getData.setUsername(x.getEmail());
                getData.setPassword(x.getPassword());
                getData.setRole(x.getRole());

                Optional<ProfileDetail> getProfileDetail = profileDetailDAO
                        .findAll()
                        .stream()
                        .filter(x1->x1.getUserID()==x.getUserId()).findFirst();

                if(!getProfileDetail.isEmpty()){
                    getData.setFullName(getProfileDetail.get().getFullName());
                    getData.setEmail(getProfileDetail.get().getEmail());
                    getData.setAddress(getProfileDetail.get().getAddress());
                    getData.setContact(getProfileDetail.get().getContact());
                }

                getDataList.add(getData);

            });

            return getDataList;

        }catch (Exception ex){
            return null;
        }
    }

    public String DeleteUserDetailL(Long Id){

        try{

            Optional<User> response = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid User Id";
            }

            Optional<ProfileDetail> getProfile = profileDetailDAO
                    .findAll()
                            .stream()
                    .filter(x->x.getUserID()==response.get().getUserId())
                            .findFirst();

            if(getProfile.isPresent()){
                profileDetailDAO.delete(getProfile.get());
            }

            userDAO.delete(response.get());

            return "Delete Profile Successfully";

        }catch (Exception ex){
            return null;
        }
    }


    //Order

    public List<OrderDetail> GeOrderDetailList(){

        try{
            return orderDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getIsOrder())
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public List<QueryDetail> GeQueryList(){

        try{
            return queryDetailDAO
                    .findAll()
                    .stream()
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public List<GetReviewDetailListDAO> GetUserReviewList(){
        try{
            List<ReviewDetail> r = reviewDetailDAO
                    .findAll()
                    .stream()

                    .toList();

            /*
            private Long id;
            private Date createdDate;
            private Long receipeId;
            private Long userId;
            private String comment;
            private String status;
            private String receipeName;
            */
            List<GetReviewDetailListDAO> getList = new ArrayList<>();
            r.forEach(x->{
                GetReviewDetailListDAO getData = new GetReviewDetailListDAO();
                getData.setId(x.getId());
                getData.setCreatedDate(x.getCreatedDate());
                getData.setReceipeId(x.getMedicineId());
                getData.setUserId(x.getUserId());
                getData.setComment(x.getComment());
                //getData.setStatus(x.getStatus());
                Optional<MedicineDetail> data = medicineDetailDAO.findAll().stream().filter(x1->x1.getId()==x.getMedicineId()).findFirst();
                String Name = "";
                if(data.isEmpty()){
                    Name = "";
                }else{
                    Name = data.get().getName();
                }
                getData.setReceipeName(Name);
                getList.add(getData);
            });
            return getList;

        }catch (Exception ex){
            return null;
        }
    }

}
