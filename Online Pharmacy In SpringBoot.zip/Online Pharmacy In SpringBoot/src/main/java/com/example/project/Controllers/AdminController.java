package com.example.project.Controllers;

import com.example.project.DTO.*;
import com.example.project.Models.MedicineDetail;
import com.example.project.Models.OrderDetail;
import com.example.project.Models.QueryDetail;
import com.example.project.Services.AdminService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("api/admin")
public class AdminController {

    @Autowired
    AdminService adminService;

    Date currentDate = new Date();

    //Medicine CRUD

    @PostMapping("/AddMedicineDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity AddMedicineDetail(@RequestBody MedicineDetail request) {
        try{

            String response = adminService.AddMedicineDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);

        }catch (Exception ex){
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/acct/payments");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/UpdateMedicineDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity UpdateMedicineDetail(@RequestBody MedicineDetail request){
        try{
            String response = adminService.UpdateMedicineDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/updatetourlocation");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/GetMedicineDetailList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetMedicineDetailList(){
        try{
            List<MedicineDetail> response = adminService.GetMedicineDetailList();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    @DeleteMapping("/DeleteMedicineDetailL")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity DeleteMedicineDetailL(@RequestParam Long Id){

        try{
            String response = adminService.DeleteMedicineDetailL(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    // UserDetail CRUD

    @PostMapping("/AddUserDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity AddUserDetail(@RequestBody UserDetailRequestDTO request) {
        try{

            String response = adminService.AddUserDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);

        }catch (Exception ex){
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/acct/payments");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/UpdateUserDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity UpdateUserDetail(@RequestBody UserDetailRequestDTO request){
        try{
            String response = adminService.UpdateUserDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/updatetourlocation");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/GetUserDetailList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetUserDetailList(){
        try{
            List<UserDetailRequestDTO> response = adminService.GetUserDetailList();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    @DeleteMapping("/DeleteUserDetailL")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity DeleteUserDetailL(@RequestParam Long Id){

        try{
            String response = adminService.DeleteUserDetailL(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }


    // Order

    @GetMapping("/GetOrderDetailList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetOrderDetailList(){
        try{
            List<OrderDetail> response = adminService.GeOrderDetailList();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    // Query

    @GetMapping("/GeQueryList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GeQueryList(){
        try{
            List<QueryDetail> response = adminService.GeQueryList();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    //

    @GetMapping("/GetUserReviewList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity GetUserReviewList() {

        try {
            List<GetReviewDetailListDAO> response = adminService.GetUserReviewList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }


}
