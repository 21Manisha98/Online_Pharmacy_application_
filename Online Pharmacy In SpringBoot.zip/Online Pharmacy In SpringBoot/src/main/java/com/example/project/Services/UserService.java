package com.example.project.Services;

import com.example.project.DTO.GetQueryDetailListDTO;
import com.example.project.DTO.GetReviewDetailListDAO;
import com.example.project.Models.*;
import com.example.project.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    MedicineDetailDAO medicineDetailDAO;

    @Autowired
    ProfileDetailDAO profileDetailDAO;

    @Autowired
    ReviewDetailDAO reviewDetailDAO;

    @Autowired
    OrderDetailDAO orderDetailDAO;

    @Autowired
    QueryDetailDAO queryDetailDAO;

    @Autowired
    UserDAO userDAO;

    // User Profile

    public String AddProfile(ProfileDetail request){
        try{

            profileDetailDAO.save(request);
            return "Add Profile Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String UpdateProfile(ProfileDetail request){
        try{

            Optional<ProfileDetail> response = profileDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(!response.isPresent()){
                return "Profile Detail Not Found";
            }

            response.get().setCreatedDate(new Date());
            response.get().setUserID(request.getUserID());
            response.get().setFullName(request.getFullName());
            response.get().setEmail(request.getEmail());
            response.get().setAddress(request.getAddress());
            response.get().setContact(request.getContact());
            profileDetailDAO.save(response.get());
            return "Update Profile Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public Optional<ProfileDetail> GetProfile(Long userID){
        try{
            return profileDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserID()==userID)
                    .findFirst();

        }catch (Exception ex){
            return null;
        }
    }

    // Order CRUD

    public String AddOrder(OrderDetail request){
        try{

            Optional<MedicineDetail> getMedicineData = medicineDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getMedicineID())
                    .findFirst();

            getMedicineData.get().setStock(getMedicineData.get().getStock()- request.getQuentity());
            medicineDetailDAO.save(getMedicineData.get());

            orderDetailDAO.save(request);
            return "Add Order Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String UpdateOrder(OrderDetail request){
        try{

            Optional<OrderDetail> response = orderDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(!response.isPresent()){
                return "Order Detail Not Found";
            }

            /*
            private Long id;
            private Date createdDate;
            private Long userID;
            private Long medicineID;
            private Long quentity;
            private Long totalPrice;
            private Boolean isOrder;
            private Boolean isWishList;
            */

            response.get().setCreatedDate(new Date());
            response.get().setUserID(request.getUserID());
            response.get().setMedicineID(request.getMedicineID());
            response.get().setQuentity(request.getQuentity());
            response.get().setTotalPrice(request.getTotalPrice());
            response.get().setIsOrder(request.getIsOrder());
            response.get().setIsWishList(request.getIsWishList());
            orderDetailDAO.save(response.get());
            return "Update Order Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public List<OrderDetail> GetOrderByUserID(Long userID){
        try{
            return orderDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserID()==userID)
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String DeleteOrderByID(Long Id){

        try{
            Optional<OrderDetail> response = orderDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Order Id";
            }

            Optional<MedicineDetail> getMedicineData = medicineDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== response.get().getMedicineID())
                    .findFirst();

            if(!getMedicineData.isEmpty()) {
                Long ResetStocks = getMedicineData.get().getStock() + response.get().getQuentity();
                getMedicineData.get().setStock(ResetStocks);
                medicineDetailDAO.save(getMedicineData.get());
            }
            orderDetailDAO.delete(response.get());

            return "Delete Order Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    //Review
    public String AddUserReview(ReviewDetail request){
        try{

            reviewDetailDAO.save(request);
            return "Add Review Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String UpdateUserReview(ReviewDetail request){
        try{

            Optional<ReviewDetail> response = reviewDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(!response.isPresent()){
                return "Profile Detail Not Found";
            }

            /*
            private Date createdDate;
            private Long receipeId;
            private Long userId;
            private String comment;
            private String status;
            */

            response.get().setCreatedDate(new Date());
            response.get().setMedicineId(request.getMedicineId());
            response.get().setUserId(request.getUserId());
            response.get().setComment(request.getComment());
            //response.get().setStatus(request.getStatus());
            reviewDetailDAO.save(response.get());
            return "Update Review Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public List<GetReviewDetailListDAO> GetUserReviewList(Long UserID){
        try{
            List<ReviewDetail> r = reviewDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserId()==UserID)
                    .toList();

            /*
            private Long id;
            private Date createdDate;
            private Long receipeId;
            private Long userId;
            private String comment;
            private String status;
            private String receipeName;
            */
            List<GetReviewDetailListDAO> getList = new ArrayList<>();
            r.forEach(x->{
                GetReviewDetailListDAO getData = new GetReviewDetailListDAO();
                getData.setId(x.getId());
                getData.setCreatedDate(x.getCreatedDate());
                getData.setReceipeId(x.getMedicineId());
                getData.setUserId(x.getUserId());
                getData.setComment(x.getComment());
                //getData.setStatus(x.getStatus());
                Optional<MedicineDetail> data = medicineDetailDAO.findAll().stream().filter(x1->x1.getId()==x.getMedicineId()).findFirst();
                String Name = "";
                if(data.isEmpty()){
                    Name = "";
                }else{
                    Name = data.get().getName();
                }
                getData.setReceipeName(Name);
                getList.add(getData);
            });
            return getList;

        }catch (Exception ex){
            return null;
        }
    }

    public String DeleteUserReview(Long Id){

        try{

            Optional<ReviewDetail> response = reviewDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Review Id";
            }

            reviewDetailDAO.delete(response.get());

            return "Delete Review Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    //Query
    public String AddQuery(QueryDetail request){
        try{

            queryDetailDAO.save(request);
            return "Add Query Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String UpdateQuery(QueryDetail request){
        try{

            Optional<QueryDetail> response = queryDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(response.isEmpty()){
                return "Query Detail Not Found";
            }

            /*
            private Date createdDate;
            private Long userID;
            private String question;
            private String answer;
            */

            response.get().setCreatedDate(new Date());
            response.get().setUserID(request.getUserID());
            response.get().setQuestion(request.getQuestion());
            response.get().setAnswer(request.getAnswer());
            queryDetailDAO.save(response.get());
            return "Update Query Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public List<GetQueryDetailListDTO> GetQueryList(Long UserID){
        try{
            List<QueryDetail> r = queryDetailDAO
                    .findAll()
                    .stream()
                    .toList();

            /*
            private Long id;
            private Date createdDate;
            private Long userID;
            private String userName;
            private String question;
            private String answer;
            */
            List<GetQueryDetailListDTO> getList = new ArrayList<>();
            r.forEach(x->{
                GetQueryDetailListDTO getData = new GetQueryDetailListDTO();
                getData.setId(x.getId());
                getData.setCreatedDate(x.getCreatedDate());
                getData.setUserID(x.getUserID());

                getData.setQuestion(x.getQuestion());
                getData.setAnswer(x.getAnswer());
                Optional<User> data = userDAO.findAll().stream().filter(x1->x1.getUserId()==x.getUserID()).findFirst();
                String UserName = "";
                if(data.isEmpty()){
                    UserName = "";
                }else{
                    UserName = data.get().getEmail();
                }
                getData.setUserName(UserName);
                getList.add(getData);
            });
            return getList;

        }catch (Exception ex){
            return null;
        }
    }

    public String DeleteQuery(Long Id){

        try{

            Optional<QueryDetail> response = queryDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Query Id";
            }

            queryDetailDAO.delete(response.get());

            return "Delete Query Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    //GetWishList

    public List<OrderDetail> GetWishList(Long UserID){
        try{
            return orderDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserID()==UserID && x.getIsWishList())
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

}
