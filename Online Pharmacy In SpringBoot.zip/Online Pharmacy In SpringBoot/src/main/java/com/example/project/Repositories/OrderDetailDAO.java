package com.example.project.Repositories;

import com.example.project.Models.MedicineDetail;
import com.example.project.Models.OrderDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderDetailDAO extends JpaRepository<OrderDetail, Long> {
}
