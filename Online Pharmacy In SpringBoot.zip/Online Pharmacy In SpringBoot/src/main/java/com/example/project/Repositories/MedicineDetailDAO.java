package com.example.project.Repositories;

import com.example.project.Models.MedicineDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicineDetailDAO extends JpaRepository<MedicineDetail, Long> {
}
