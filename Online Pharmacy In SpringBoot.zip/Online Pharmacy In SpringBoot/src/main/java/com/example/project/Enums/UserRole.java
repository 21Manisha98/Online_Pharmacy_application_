package com.example.project.Enums;

public enum UserRole {
    USER,
    ADMIN
}
