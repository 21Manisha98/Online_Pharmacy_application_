package com.example.project.DTO;

import com.example.project.Enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDetailRequestDTO {
    //User Table
    private Long userId;
    private String username;
    private String  password;
    private UserRole role;

    //Profile Table
    //private Long userID;
    private String fullName;
    private String email;
    private String address;
    private String contact;
}
