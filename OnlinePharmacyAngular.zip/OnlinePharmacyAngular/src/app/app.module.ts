import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import {
  BrowserModule,
  // provideClientHydration,
} from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';

import { FormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { NgxSpinnerModule } from 'ngx-spinner';

import { MaterialUiModule } from './shared/material-ui/material-ui.module';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RpasswordComponent } from './pages/rpassword/rpassword.component';
import { UserdashboardComponent } from './pages/userdashboard/userdashboard.component';
import { AdmindashboardComponent } from './pages/admindashboard/admindashboard.component';
import { AdminhomeComponent } from './pages/adminhome/adminhome.component';
import { UserhomeComponent } from './pages/userhome/userhome.component';
import { MyOrderComponent } from './pages/usermyorder/usermyorder.component';
import { UserprofileComponent } from './pages/userprofile/userprofile.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { WelcomepageComponent } from './pages/welcomepage/welcomepage.component';
import { AdminReviewComponent } from './pages/adminreview/adminreview.component';
import { UserReviewComponent } from './pages/userreview/userreview.component';
import { MatDialogModule } from '@angular/material/dialog';
import { orderdialogComponent } from './pages/orderdialog/orderdialog.component';
import { UserwishlistComponent } from './pages/userwishlist/userwishlist.component';
import { UserhelpComponent } from './pages/userhelp/userhelp.component';
import { AdminprofileComponent } from './pages/adminprofile/adminprofile.component';
import { AdminorderComponent } from './pages/adminorder/adminorder.component';
import { AdminqueryComponent } from './pages/adminquery/adminquery.component';
@NgModule({
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  declarations: [
    AppComponent,
    SigninComponent,
    SignupComponent,
    RpasswordComponent,
    UserdashboardComponent,
    AdmindashboardComponent,
    AdminhomeComponent,
    UserhomeComponent,
    MyOrderComponent,
    UserprofileComponent,
    WelcomepageComponent,
    AdminReviewComponent,
    UserReviewComponent,
    orderdialogComponent,
    UserwishlistComponent,
    UserhelpComponent,
    AdminprofileComponent,
    AdminorderComponent,
    AdminqueryComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    NgxSpinnerModule,
    FormsModule,
    MaterialUiModule,
    MatDialogModule
  ],
  providers: [provideAnimationsAsync()],
  bootstrap: [AppComponent],
})
export class AppModule {}
