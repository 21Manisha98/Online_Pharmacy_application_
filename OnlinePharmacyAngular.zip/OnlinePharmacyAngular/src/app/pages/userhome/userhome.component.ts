import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { saveAs } from 'file-saver';
import { orderdialogComponent } from '../orderdialog/orderdialog.component';
@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrl: './userhome.component.css',
})
export class UserhomeComponent {
  List: any[] = [];
  userID = 0;
  ID = 0;
  Quentity = 0;
  Stock = 0;
  IsEdit = false;
  Status = false;
  UserStatus = '';
  UserReview = false;
  IsInfoView = false;
  Price = 0;
  TotalPrice = 0;
  DiscountPrice = 0;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public serviceService: UserService,
    private businessService: AdminService,
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar
  ) {
    this.userID = this._localStorage.getItem('User-Id');
  }

  ngOnInit(): void {
    // debugger;
    this.GetMedicineDetailList();
  }

  GetMedicineDetailList() {
    this.businessService.GetMedicineDetailList().subscribe((result: any) => {
      console.log('Result : ', result.length);
      // debugger;
      this.List = result;
    });
  }

  handleDownloadOffer(url: any) {
    saveAs(url, 'OfferLetter.pdf');
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  async handleCopy(data: any) {
    await this.handleVisibility();

    this.ID = data.id;
    $('#name').text(data.name);
    $('#description').text(data.description);
    $('#category').text(data.category);
    $('#price').text(data.price);
    this.Price = data.price;
    $('#disease').text(data.diseases);
    $('#stock').text(data.stock);
    this.Stock = data.stock;
    this.Status = data.isActive;
    this.IsEdit = true;
    this.UserReview = true;
  }

  handleVisibility() {
    this.IsInfoView = true;
  }

  handleDelete(id: any) {}

  handleSubmit() {
    // debugger;
    if (this.Quentity <= 0) {
      this.openSnackBar('Quentity must be greater than 0');
      return;
    }

    let data = {
      createdDate: new Date(),
      userID: this.userID,
      medicineID: this.ID,
      quentity: this.Quentity,
      totalPrice: this.DiscountPrice,
      isOrder: false,
      isWishList: false,
    };

    this.serviceService.AddOrder(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add Order Successfully');
        this.UserReview = false;
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleCategorySearch() {
    if ($('#category').val() === '') {
      this.GetMedicineDetailList();
      return;
    }

    // this.serviceService.GetReceipesByCategory($('#category').val()).subscribe({
    //   next: (result: any) => {
    //     console.log('Result : ', result);
    //     this.List = result;
    //   },
    //   error: (error: any) => {
    //     console.log('Error : ', error);
    //     this.openSnackBar('Something went wrong');
    //   },
    // });
  }

  handleSearchClear() {
    $('#keyword').val('');
    this.GetMedicineDetailList();
  }

  handleSearch() {
    let key: any = '';
    if ($('#keyword').val() === '') {
      this.GetMedicineDetailList();
      return;
    }

    key = $('#keyword').val();

    this.businessService.GetMedicineDetailList().subscribe({
      next: (result: any) => {
        console.log('Result : ', result.length);
        this.List =
          result.length > 0 &&
          result.filter((x: any) => x.diseases.toLowerCase() === key.toLowerCase());
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleClear() {
    $('#nameHelp').hide();
    $('#descriptionHelp').hide();
    $('#categoryHelp').hide();
    $('#priceHelp').hide();
    $('#diseaseHelp').hide();
    $('#stockHelp').hide();
    this.IsEdit = false;
    // debugger;
    $('#name').text('');
    $('#description').text('');
    $('#category').text('');
    $('#price').text('');
    $('#disease').text('');
    $('#stock').text('');
    $('#totalprice').text('');

    $('#keyword').text('');
    this.Status = false;

    this.UserReview = false;
    this.GetMedicineDetailList();
    this.IsInfoView = false;
  }

  handleQuentity(status: any) {
    // debugger;
    this.UserStatus = status;
    if (this.Stock >= 0) {
      if (status) {
        if (this.Quentity < this.Stock) this.Quentity += 1;
      } else {
        if (this.Quentity > 0) this.Quentity -= 1;
      }
      $('#quentity').val(this.Quentity);
      $('#totalprice').val(this.Price * this.Quentity);
      this.TotalPrice = this.Price * this.Quentity; //totalprice

      if (this.TotalPrice > 499 && this.TotalPrice < 999) {
        this.DiscountPrice = this.TotalPrice * 0.9;
      } else if (this.TotalPrice > 999) {
        this.DiscountPrice = this.TotalPrice * 0.85;
      } else {
        this.DiscountPrice = this.TotalPrice;
      }
    } else {
      this.openSnackBar('Product Is Unavailable');
    }
    $('#userstatus').val(status ? 'LIKE' : 'UNLIKE');
  }

  handleWishlist() {
    let data = {
      createdDate: new Date(),
      userID: this.userID,
      medicineID: this.ID,
      quentity: 0,
      totalPrice: 0,
      isOrder: false,
      isWishList: true,
    };

    this.serviceService.AddOrder(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add Wishlist Successfully');
        this.UserReview = false;
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }
}
