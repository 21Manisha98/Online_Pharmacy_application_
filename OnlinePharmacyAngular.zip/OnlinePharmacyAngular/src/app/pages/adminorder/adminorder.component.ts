import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { AdminService } from '../../services/admin.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-adminorder',
  templateUrl: './adminorder.component.html',
  styleUrl: './adminorder.component.css'
})
export class AdminorderComponent {
  UserName = '';
  List: any[] = [];
  UserID = 0;
  ID = 0;
  MedicineID = 0;
  IsReview = false;
  selectedFile: any;
  DocURL = '';
  IsEdit = false;
  Name: any = '';
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    private router: Router,
    private serviceService: UserService,
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private adminService: AdminService
  ) {
    this.UserID = Number(this._localStorage.getItem('User-Id'));
    this.UserName = this._localStorage.getItem('User-Email');
  }

  ngOnInit(): void {
    this.GetOrderDetailList();
  }

  GetOrderDetailList() {
    this.adminService.GetOrderDetailList().subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
      },
    });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleCopy(data: any) {
    $('#name').val(data.name);
    this.ID = data.id;
    this.DocURL = data.fileURL;
    this.IsEdit = true;
  }

  handleIsCancelOrder(id: any) {
    this.serviceService.DeleteOrderByID(id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.GetOrderDetailList();
        this.openSnackBar('Delete User Order Successfully');
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleValidation() {
    $('#nameHelp').hide();
    $('#fileHelp').hide();
    let Value = false;
    if ($('#name').val() === '') {
      $('#nameHelp').show();
      Value = true;
    }
    if (!this.IsEdit && this.selectedFile === undefined) {
      $('#fileHelp').show();
      Value = true;
    }

    return Value;
  }

  handleAdd() {
    if (this.handleValidation()) {
      return;
    }

    this.Name = $('#name').val();

    const data: FormData = new FormData();
    data.append('UserID', this.UserID.toString());
    data.append('Name', this.Name.toString());
    data.append('File', this.selectedFile);

  }

  handleIsOrder(data: any) {
    let _data = {
      id: data.id,
      createdDate: new Date(),
      userID: this.UserID,
      medicineID: data.medicineID,
      quentity: data.quentity,
      totalPrice: data.totalPrice,
      isOrder: true,
      isWishList: false,
    };
    // debugger;
    this.serviceService.UpdateOrder(_data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.GetOrderDetailList();
        this.openSnackBar('Update User Order Successfully');
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleClear() {
    $('#name').val('');
    this.selectedFile = '';
    this.DocURL = '';
    this.IsEdit = false;
  }

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
    console.log('File : ', this.selectedFile);
    this.DocURL = '';
  }

  handledownload(url: any) {
    saveAs(url, 'Receipe Document.pdf');
  }

  handleIsReview(id: any) {
    this.MedicineID = id;
    this.IsReview = true;
  }

  handleSumitReview() {
    debugger;
    $('#reviewHelp').hide();
    if ($('#comment').val() === '') {
      $('#reviewHelp').show();
      return;
    }

    let data = {
      medicineId: this.MedicineID,
      userId: this.UserID,
      comment: $('#comment').val(),
    };
    this.serviceService.AddUserReview(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        $('#comment').val('');
        this.MedicineID = 0;
        this.IsReview = false;
        this.openSnackBar('Add Review Successfully');
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }
}
