import { ComponentFixture, TestBed } from '@angular/core/testing';

import { orderdialogComponent } from './orderdialog.component';

describe('orderdialogComponent', () => {
  let component: orderdialogComponent;
  let fixture: ComponentFixture<orderdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [orderdialogComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(orderdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
