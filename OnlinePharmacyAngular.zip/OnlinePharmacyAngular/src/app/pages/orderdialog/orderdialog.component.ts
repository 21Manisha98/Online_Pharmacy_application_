import { Component, Inject } from '@angular/core';
import $ from 'jquery';
import { NgxSpinnerService } from 'ngx-spinner';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { localStorageSession } from '../../shared/localStorage';
import { UserService } from '../../services/user.service';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
@Component({
  selector: 'app-orderdialog',
  templateUrl: './orderdialog.component.html',
  styleUrl: './orderdialog.component.css',
})
export class orderdialogComponent {
  ID = 0;
  IsEdit = false;
  Status = false;
  UserReview = false;
  IsInfoView = false;
  UserStatus = '';
  userID = 0;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  Name = '';
  MedicineID = '';
  Quentity = '';
  TotalPrice = '';
  IsOrder = '';
  CreatedDate = '';
  commentHelp = false;
  Comment = '';
  constructor(
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _localStorage: localStorageSession,
    public serviceService: UserService
  ) {
    this.userID = this._localStorage.getItem('User-Id');
    this.ID = data.id;
    // this.Name = data.name;
    this.MedicineID = data.medicineID;
    this.Quentity = data.quentity;
    this.TotalPrice = data.totalPrice;
    this.IsOrder = data.isOrder ? 'Order Is Placed' : '';
    this.CreatedDate = data.createdDate;
    this.IsEdit = true;
    this.UserReview = true;
    // debugger;

  }

  ngOnInit() {}

  handleClear() {
    $('#orderHelp').hide();
    $('#categoryHelp').hide();
    $('#commentHelp').hide();
    this.IsEdit = false;

    $('#name').val('');
    $('#description').val('');
    $('#ingredients').val('');
    $('#order').val('');
    $('#category').val('');
    $('#comment').val('');

    $('#keyword').val('');
    this.Status = false;

    this.UserReview = false;
    // this.GetReceipesDetailList();
    this.IsInfoView = false;
    this.Comment = '';
    this.dialog.closeAll();
  }


  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleValue(event: any) {
    this.Comment = event.target.value;
  }

  handleSubmit() {
    // debugger;

    let DATA: any = document.getElementById('htmlData');
    html2canvas(DATA).then((canvas) => {
      let fileWidth = 208;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;
      const FILEURI = canvas.toDataURL('image/png');
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 0;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
      PDF.save('MEDICINE INFORMATION.pdf');
    });
  
  }
}
