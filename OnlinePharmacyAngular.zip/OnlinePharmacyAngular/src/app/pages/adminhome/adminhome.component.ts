import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MyOrderComponent } from '../usermyorder/usermyorder.component';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { saveAs } from 'file-saver';
import { localStorageSession } from '../../shared/localStorage';
@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css',
})
export class AdminhomeComponent {
  List: any[] = [];
  userID = 0;
  ID = 0;
  IsEdit = false;
  Status = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'start';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public businessService: AdminService,
    private _snackBar: MatSnackBar,
    private _localStorage: localStorageSession
  ) {
    this.userID = Number(this._localStorage.getItem('Admin-Id'));
  }

  ngOnInit(): void {
    this.GetMedicineDetailList();
  }

  GetMedicineDetailList() {
    this.businessService.GetMedicineDetailList().subscribe((result: any) => {
      console.log('Result : ', result);
      this.List = result;
    });
  }

  handleDelete(id: number) {
    this.businessService.DeleteMedicineDetailL(id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete Medicine Detail Successfully');
        this.GetMedicineDetailList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleNevigateTour() {
    this.router.navigate(['/admindashboard/adminMovie/0/false']);
  }

  handleCopy(data: any) {
    this.ID = data.id;
    $('#name').val(data.name);
    $('#description').val(data.description);
    $('#price').val(data.price);
    $('#stock').val(data.stock);
    $('#category').val(data.category);
    $('#disease').val(data.diseases);
    this.Status = data.isActive;
    this.IsEdit = true;
    // debugger;
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'close', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleSubmit() {
    if (this.IsEdit) {
      this.handleEdit();
    } else {
      this.handleAdd();
    }
  }

  handleAdd() {
    console.log('Status : ', $('#status').is(':checked'));
    if (this.handleValidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      userID: this.userID,
      name: $('#name').val(),
      description: $('#description').val(),
      createdDate: new Date(),
      category: $('#category').val(),
      price: Number($('#price').val()),
      diseases: $('#disease').val(),
      stock: Number($('#stock').val()),
    };

    this.businessService.AddMedicineDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add Medicine Detail Successfully');
        this.GetMedicineDetailList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleStatus(event: any) {
    console.log('Event : ', event.target.checked);
    this.Status = event.target.checked;
  }

  handleEdit() {
    if (this.handleValidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      id: this.ID,
      userID: this.userID,
      name: $('#name').val(),
      description: $('#description').val(),
      category: $('#category').val(),
      createdDate: new Date(),
      price: Number($('#price').val()),
      diseases: $('#disease').val(),
      stock: Number($('#stock').val()),
    };
    // debugger;
    this.businessService.UpdateMedicineDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Update Medicine Detail Successfully');
        this.GetMedicineDetailList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleValidation() {
    $('#nameHelp').hide();
    $('#descriptionHelp').hide();
    $('#priceHelp').hide();
    $('#stockHelp').hide();
    $('#categoryHelp').hide();
    $('#diseaseHelp').hide();

    let Value = false;
    if ($('#name').val() === '') {
      $('#nameHelp').show();
      Value = true;
    }
    if ($('#description').val() === '') {
      $('#descriptionHelp').show();
      Value = true;
    }
    if (Number($('#price').val()) <= 0) {
      $('#priceHelp').show();
      Value = true;
    }
    if ($('#disease').val() === '') {
      $('#diseaseHelp').show();
      Value = true;
    }
    if ($('#category').val() === '') {
      $('#categoryHelp').show();
      Value = true;
    }
    if (Number($('#stock').val()) <= 0) {
      $('#stockHelp').show();
      Value = true;
    }

    return Value;
  }

  handleClear() {
    $('#nameHelp').hide();
    $('#descriptionHelp').hide();
    $('#priceHelp').hide();
    $('#stockHelp').hide();
    $('#categoryHelp').hide();
    $('#diseaseHelp').hide();
    this.IsEdit = false;

    $('#name').val('');
    $('#description').val('');
    $('#price').val('');
    $('#stock').val('');
    $('#disease').val('');
    $('#category').val('');
    this.Status = false;
  }
}
