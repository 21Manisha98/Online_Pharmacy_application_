import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MyOrderComponent } from '../usermyorder/usermyorder.component';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { saveAs } from 'file-saver';
import { localStorageSession } from '../../shared/localStorage';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrl: './adminprofile.component.css',
})
export class AdminprofileComponent {
  List: any[] = [];
  userID = 0;
  ID = 0;
  IsEdit = false;
  Status = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'start';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public businessService: AdminService,
    private _snackBar: MatSnackBar,
    private _localStorage: localStorageSession
  ) {
    //this.userID = Number(this._localStorage.getItem('Admin-Id'));
  }

  ngOnInit(): void {
    this.GetUserDetailList();
  }

  GetUserDetailList() {
    this.businessService.GetUserDetailList().subscribe((result: any) => {
      console.log('Result : ', result);
      this.List = result;
    });
  }

  handleDelete(id: number) {
    this.businessService.DeleteUserDetailL(id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete User Detail Successfully');
        this.GetUserDetailList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleNevigateTour() {
    this.router.navigate(['/admindashboard/adminMovie/0/false']);
  }

  handleCopy(data: any) {

    this.userID = data.userId;
    $('#fullname').val(data.fullName);
    $('#username').val(data.username);
    $('#password').val(data.password);
    $('#email').val(data.email);
    $('#address').val(data.address);
    $('#contact').val(data.contact);
    this.Status = data.isActive;
    this.IsEdit = true;
    // debugger;
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'close', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleSubmit() {
    if (this.IsEdit) {
      this.handleEdit();
    } else {
      this.handleAdd();
    }
  }

  handleAdd() {
    console.log('Status : ', $('#status').is(':checked'));
    if (this.handleValidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      userId: this.userID,
      username: $('#username').val(),
      password: $('#password').val(),
      role: 'USER',
      fullName: $('#fullname').val(),
      email: $('#email').val(),
      address: $('#address').val(),
      contact: $('#contact').val(),
    };

    this.businessService.AddUserDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add User Detail Successfully');
        this.GetUserDetailList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleStatus(event: any) {
    console.log('Event : ', event.target.checked);
    this.Status = event.target.checked;
  }

  handleEdit() {
    if (this.handleValidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      userId: this.userID,
      username: $('#username').val(),
      password: $('#password').val(),
      role: 'USER',
      fullName: $('#fullname').val(),
      email: $('#email').val(),
      address: $('#address').val(),
      contact: $('#contact').val(),
    };
    // debugger;
    this.businessService.UpdateUserDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Update User Detail Successfully');
        this.GetUserDetailList();
        this.handleClear();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleValidation() {
    $('#fullnameHelp').hide();
    $('#usernameHelp').hide();
    $('#passwordHelp').hide();
    $('#emailHelp').hide();
    $('#addressHelp').hide();
    $('#contactHelp').hide();

    let Value = false;
    if ($('#username').val() === '') {
      $('#usernameHelp').show();
      Value = true;
    }
    if ($('#password').val() === '') {
      $('#passwordHelp').show();
      Value = true;
    }
    if ($('#fullname').val() === '') {
      $('#fullnameHelp').show();
      Value = true;
    }
    if ($('#email').val() === '') {
      $('#emailHelp').show();
      Value = true;
    }
    if ($('#address').val() === '') {
      $('#addressHelp').show();
      Value = true;
    }
    if ($('#contact').val() === '') {
      $('#contactHelp').show();
      Value = true;
    }

    return Value;
  }

  handleClear() {
    $('#fullnameHelp').hide();
    $('#usernameHelp').hide();
    $('#passwordHelp').hide();
    $('#emailHelp').hide();
    $('#addressHelp').hide();
    $('#contactHelp').hide();
    this.IsEdit = false;

    $('#fullname').val('');
    $('#username').val('');
    $('#password').val('');
    $('#email').val('');
    $('#address').val('');
    $('#contact').val('');
    this.Status = false;
  }
}
