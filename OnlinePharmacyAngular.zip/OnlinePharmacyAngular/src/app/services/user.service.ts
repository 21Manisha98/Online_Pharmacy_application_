import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.User;

// const _authToken = localStorage.getItem('Admin-Token');

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
  });

  multipartheaders = new HttpHeaders({
    // 'Content-Type': 'multipart/form-data',
    Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
  });

  //

  AddProfile(data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.AddProfile, data, {
      headers: this.multipartheaders,
    });
  }

  UpdateProfile(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.UpdateProfile, _data, {
      headers: this.multipartheaders,
    });
  }

  GetProfile(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetProfile + '?UserId=' + data,
      {
        headers: this.headers,
      }
    );
  }

  //

  AddOrder(_data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.AddOrder, _data, {
      headers: this.headers,
    });
  }

  UpdateOrder(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.UpdateOrder, _data, {
      headers: this.headers,
    });
  }

  GetOrderByUserID(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetOrderByUserID + '?UserId=' + data,
      {
        headers: this.headers,
      }
    );
  }

  DeleteOrderByID(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.DeleteOrderByID + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  //

  AddQuery(data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.AddQuery, data, {
      headers: this.multipartheaders,
    });
  }

  UpdateQuery(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.UpdateQuery, _data, {
      headers: this.multipartheaders,
    });
  }

  GetQueryList(_data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetQueryList + '?UserID=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  DeleteQuery(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.DeleteQuery + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  //

  AddUserReview(data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.AddUserReview, data, {
      headers: this.multipartheaders,
    });
  }

  UpdateUserReview(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.UpdateUserReview, _data, {
      headers: this.multipartheaders,
    });
  }

  GetUserReviewList(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetUserReviewListByUserID + '?UserID=' + data,
      {
        headers: this.headers,
      }
    );
  }

  DeleteUserReview(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.DeleteUserReview + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  //

  GetWishList(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.GetWishList + '?UserID=' + data,
      {
        headers: this.headers,
      }
    );
  }
}
