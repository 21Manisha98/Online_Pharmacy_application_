import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.Admin;

// const _authToken = localStorage.getItem('Admin-Token');

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
  });

  multipartheaders = new HttpHeaders({
    // 'Content-Type': 'multipart/form-data',
    Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
  });

  // 'Content-Type', 'text/plain'
  AddMedicineDetail(_data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.AddMedicineDetail, _data, {
      headers: this.multipartheaders,
    });
  }

  UpdateMedicineDetail(_data: any) {
    return this._httpClient.put(
      _baseUrl + _apiUrl.UpdateMedicineDetail,
      _data,
      {
        headers: this.multipartheaders,
      }
    );
  }

  GetMedicineDetailList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetMedicineDetailList, {
      headers: this.headers,
    });
  }

  DeleteMedicineDetailL(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.DeleteMedicineDetailL + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  AddUserDetail(_data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.AddUserDetail, _data, {
      headers: this.multipartheaders,
    });
  }

  UpdateUserDetail(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.UpdateUserDetail, _data, {
      headers: this.multipartheaders,
    });
  }

  GetUserDetailList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetUserDetailList, {
      headers: this.headers,
    });
  }

  DeleteUserDetailL(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.DeleteUserDetailL + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  GetOrderDetailList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetOrderDetailList, {
      headers: this.headers,
    });
  }

  GetUserReviewList() {
    return this._httpClient.get(_baseUrl + _apiUrl.GetUserReviewList, {
      headers: this.headers,
    });
  }
}
