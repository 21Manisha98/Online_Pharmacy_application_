export const environment = {
    production: false,
  
    BEServer: {
      DevEnviroment: 'http://localhost:8080/api/',
    },
  };
  