export const apiUrls = {
  Authentication: {
    SignIn: 'auth/login',
    SignUp: 'auth/signup',
    findEmail: 'auth/findEmail',
    changepassword: 'auth/changepassword',
  },
  Admin: {
    AddMedicineDetail: 'admin/AddMedicineDetail',
    UpdateMedicineDetail: 'admin/UpdateMedicineDetail',
    GetMedicineDetailList: 'admin/GetMedicineDetailList',
    DeleteMedicineDetailL: 'admin/DeleteMedicineDetailL',

    AddUserDetail: 'admin/AddUserDetail',
    UpdateUserDetail: 'admin/UpdateUserDetail',
    GetUserDetailList: 'admin/GetUserDetailList',
    DeleteUserDetailL: 'admin/DeleteUserDetailL',

    GetOrderDetailList: 'admin/GetOrderDetailList',
    GetUserReviewList: 'admin/GetUserReviewList',
  },
  User: {
    AddProfile: 'user/AddProfile',
    UpdateProfile: 'user/UpdateProfile',
    GetProfile: 'user/GetProfile',

    AddOrder: 'user/AddOrder',
    UpdateOrder: 'user/UpdateOrder',
    GetOrderByUserID: 'user/GetOrderByUserID',
    DeleteOrderByID: 'user/DeleteOrderByID',

    AddUserReview: 'user/AddUserReview',
    UpdateUserReview: 'user/UpdateUserReview',
    GetUserReviewListByUserID: 'user/GetUserReviewListByUserID',
    DeleteUserReview: 'user/DeleteUserReview',

    AddQuery: 'user/AddQuery',
    UpdateQuery: 'user/UpdateQuery',
    GetQueryList: 'user/GetQueryList',
    DeleteQuery: 'user/DeleteQuery',

    GetWishList: 'user/GetWishList',
  },
};
